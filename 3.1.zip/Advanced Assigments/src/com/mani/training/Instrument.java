package com.mani.training;

public class Instrument {

	public abstract void play();
}
